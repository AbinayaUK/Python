"""import module"""
import unittest
from src.Arithmetic_calc import calc_arith


class Test(unittest.TestCase):
    """main class of the program"""
    def test_addition(self):
        """calculating the positive addition value"""
        self.assertEqual(calc_arith.addition(2, 2), 4)

    def test_subtraction(self):
        """calculating the subtraction value"""
        self.assertEqual(calc_arith.subtraction(5, 3), 2)

    def test_multipy(self):
        """calculating the multiplication """
        self.assertEqual(calc_arith.multiply(5, 3), 15)

    def test_divide(self):
        """calculating the division"""
        self.assertEqual(calc_arith.divide(4, 2), 2)

    def test_error(self):
        """non integer inputs"""
        self.assertEqual(calc_arith.addition(2, 'a'), "Enter only numbers")

    def test_zeroerror(self):
        """non integer inputs"""
        self.assertEqual(calc_arith.divide(2, 0), "Enter a number greater than zero")

if __name__ == '__main__':
    unittest.main()
