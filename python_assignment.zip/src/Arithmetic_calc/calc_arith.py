"""arithmetic operation"""


def addition(input1, input2):
    """calculating addition"""
    try:
        a_input = float(input1)
        b_input = float(input2)
        return a_input + b_input
    except ValueError:
        print "ValueError"
        return "Enter only numbers"


def subtraction(input1, input2):
    """calculating subtraction"""
    try:
        a_input = float(input1)
        b_input = float(input2)
        return a_input - b_input
    except ValueError:
        print "ValueError"
        return "Enter only numbers"


def multiply(input1, input2):
    """calculating multiply"""
    try:
        a_input = float(input1)
        b_input = float(input2)
        return a_input * b_input
    except ValueError:
        print "ValueError"
        return "Enter only numbers"


def divide(input1, input2):
    """calculating divide"""
    try:
        a_input = float(input1)
        b_input = float(input2)
        return a_input / b_input
    except ValueError:
        print ValueError
        return "Enter only numbers"
    except ZeroDivisionError:
        print "ZeroDivisionError"
        return "Enter a number greater than zero"
