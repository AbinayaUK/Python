from src.Arithmetic_calc import calc_arith
import sys

def main():
   input1 = sys.argv[1]
   input2 = sys.argv[2]
   result1 = calc_arith.addition(input1, input2)
   print(result1)
   result2 = calc_arith.subtraction(input1, input2)
   print(result2)
   result3 = calc_arith.multiply(input1, input2)
   print(result3)
   result4 = calc_arith.divide(input1, input2)
   print(result4)
